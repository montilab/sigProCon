library(testthat)
library(sigProCon)

test_check("sigProCon")
